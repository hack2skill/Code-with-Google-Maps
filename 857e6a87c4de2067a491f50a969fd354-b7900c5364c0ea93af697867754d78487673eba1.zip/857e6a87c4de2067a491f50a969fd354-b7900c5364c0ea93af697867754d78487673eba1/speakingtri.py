import cv2
import cvlib
from cvlib.object_detection import draw_bbox
import pyttsx3
import googlemaps

# Initialize the video capture for object detection
video_capture = cv2.VideoCapture(0)
engine = pyttsx3.init()

# Initialize the Google Maps API client
gmaps = googlemaps.Client(key='AIzaSyDh3r-9NYFpvZDJ6H-W2W0jRmayAOtmnQI')

# Function for object detection (you can replace this with your object detection code)
def detect_objects(frame):
    bbox, label, conf = cvlib.detect_common_objects(frame, model='yolov3', confidence=0.5)
    output_frame = draw_bbox(frame, bbox, label, conf)
    return label, output_frame

# Function to get directions
def get_directions(start, destination):
    directions = gmaps.directions(start, destination, mode="driving")
    if directions:
        return directions[0]['legs'][0]['steps']
    return []

# Function to speak detected objects
def speak_detected_objects(detected_objects):
    engine.say("I see the following objects: " + ", ".join(detected_objects))
    engine.runAndWait()

while True:
    ret, frame = video_capture.read()

    if ret:
        frame = cv2.resize(frame, (640, 480))
        detected_objects, output_frame = detect_objects(frame)
        speak_detected_objects(detected_objects)
        cv2.imshow('Object Detection', output_frame)

    command = input("Type a command: ").lower()

    if "location" in command:
        start = input("Please specify your starting point: ").lower()
        destination = input("Now, specify your destination: ").lower()
        directions = get_directions(start, destination)
        if directions:
            for step in directions:
                engine.say(step['html_instructions'])
                engine.runAndWait()
        else:
            engine.say("Sorry, I couldn't find directions.")
            engine.runAndWait()

    if command == "exit":
        break

video_capture.release()
cv2.destroyAllWindows()
engine.stop()
